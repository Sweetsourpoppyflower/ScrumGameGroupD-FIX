public class KamerInfo extends Readable {
    void showMessage(String message) {
        System.out.println("Dit is een interactief object dat informatie geeft over de kamer.");
        System.out.println("Informatie: " + message);
    }

}
