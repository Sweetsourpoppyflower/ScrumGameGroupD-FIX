public interface VoortgangsMonitor {

    void update(Speler speler);
    
    String getVoortgangsInfo();
}
