# Dependency Inversion Principle Schendingen - Analyse en Oplossingen

## Inhoudsopgave
1. [Inleiding tot het Dependency Inversion Principle](#inleiding)
2. [Geïdentificeerde DIP Schendingen](#schendingen)
3. [Concrete Oplossingsstrategieën](#oplossingen)
4. [Implementatie Roadmap](#roadmap)
5. [Voor/Na Code Vergelijkingen](#vergelijkingen)
6. [Testing Strategieën](#testing)
7. [Conclusie](#conclusie)

---

## 1. Inleiding tot het Dependency Inversion Principle {#inleiding}

Het **Dependency Inversion Principle (DIP)** is het vijfde en laatste principe van de SOLID principes en stelt dat:

> *"Hoog-niveau modules moeten niet afhankelijk zijn van lage-niveau modules. Beide moeten afhankelijk zijn van abstracties (interfaces of abstracte klassen), niet van concrete implementaties."*

### Kernregels van DIP:
- **Hoog-niveau modules** (business logic) mogen niet direct afhangen van **lage-niveau modules** (infrastructure, database, UI)
- **Afhankelijkheden moeten worden geïnjecteerd** via constructor, setter of interface
- **Abstracties** (interfaces/abstract klassen) moeten de koppeling tussen modules definiëren
- **Code moet duidelijk tonen** dat abstrahering afhankelijkheden omkeert

### Waarom DIP belangrijk is:
- Zorgt voor **losse koppeling** tussen modules
- Maakt **unit testing** mogelijk door dependency injection
- Verbetert **flexibiliteit** - implementaties kunnen worden gewisseld
- Voorkomt **circulaire afhankelijkheden**
- Maakt **Inversion of Control (IoC)** mogelijk

### DIP vs Dependency Injection:
- **DIP** = Het principe (abstracties, niet concrete klassen)
- **Dependency Injection** = Een implementatietechniek voor DIP
- **IoC Container** = Een framework dat DI automatiseert

---

## 2. Geïdentificeerde DIP Schendingen {#schendingen}

### Schending 1: Speler.java - Hard-coded Repository Afhankelijkheid

#### **Probleem Beschrijving**
De `Speler` klasse (hoog-niveau business logic) hangt direct af van de concrete `SpelerRepository` klasse (lage-niveau data access), wat een fundamentele DIP schending is.

#### **Huidige Code**
```java
public class Speler {
    private String naam;
    private int scrumKennis;
    private SpelerRepository repository;  // ← Directe afhankelijkheid van concrete klasse
    
    public Speler(String naam) {
        this.naam = naam;
        this.repository = new SpelerRepository();  // ← Hard-coded instantiatie
        repository.saveSpeler(this);
    }
    
    public void verhoogScrumKennis(int aantal) {
        this.scrumKennis += aantal;
        repository.updateScrumKennis(this.naam, this.scrumKennis);  // ← Direct gebruik
        notifyObservers();
    }
}
```

#### **DIP Schending Analyse**
- **Hoog-niveau module** (`Speler` - business logic) hangt af van **lage-niveau module** (`SpelerRepository` - data access)
- **Geen abstractie**: Directe koppeling aan concrete implementatie
- **Niet testbaar**: Kan niet gemockt worden voor unit tests
- **Niet flexibel**: Kan niet switchen naar andere storage implementaties
- **Tight coupling**: Wijzigingen in repository breken Speler klasse

#### **Impact**
```java
// Deze code is NIET testbaar:
@Test
public void testVerhoogScrumKennis() {
    Speler speler = new Speler("Test");  // ← Maakt echte database connectie!
    speler.verhoogScrumKennis(5);
    // Kan niet testen zonder database
}
```

---

### Schending 2: SleutelJoker.java - Statische Afhankelijkheid

#### **Probleem Beschrijving**
De `SleutelJoker` klasse gebruikt een statische methode om de huidige speler op te halen, wat een verborgen afhankelijkheid creëert en DIP schendt.

#### **Huidige Code**
```java
public class SleutelJoker extends Joker {
    @Override
    protected void doeGebruikIn(Kamer kamer) {
        System.out.println("🔑 Sleutel Joker geactiveerd!");
        Speler speler = Spel.getHuidigeSpeler();  // ← Statische afhankelijkheid
        kamer.geefExtraSleutel(speler);
        System.out.println("Je hebt nu " + speler.getAantalSleutels() + " sleutels.");
    }
}
```

#### **DIP Schending Analyse**
- **Verborgen afhankelijkheid**: Niet duidelijk uit constructor/interface
- **Statische koppeling**: Kan niet worden geïnjecteerd of gemockt
- **Niet testbaar**: Test hangt af van globale staat
- **Tight coupling**: Direct gekoppeld aan `Spel` klasse implementatie

#### **Impact**
```java
// Deze code is NIET testbaar:
@Test
public void testSleutelJokerGebruik() {
    SleutelJoker joker = new SleutelJoker();
    Kamer kamer = new KamerDaily("test", "test");
    
    joker.gebruikIn(kamer);  // ← Faalt omdat Spel.getHuidigeSpeler() null is
}
```

---

### Schending 3: Spel.java - Concrete Input/Output Afhankelijkheden

#### **Probleem Beschrijving**
De `Spel` klasse is direct gekoppeld aan concrete `Scanner` en `System.out` implementaties, wat flexibiliteit en testbaarheid beperkt.

#### **Huidige Code**
```java
public class Spel {
    private Scanner scanner;  // ← Directe afhankelijkheid van concrete input
    
    public Spel(String spelNaam) {
        this.scanner = new Scanner(System.in);  // ← Hard-coded input source
    }
    
    public void start() throws SQLException {
        System.out.println("Welkom bij " + spelNaam + "!");  // ← Hard-coded output
        System.out.print("Voer je naam in: ");
        String naam = scanner.nextLine();  // ← Direct gebruik van concrete scanner
        
        // ... rest van implementatie
    }
    
    public void kiesJoker(Speler speler) {
        System.out.println("Wil je een HintJoker of een SleutelJoker? (hint/sleutel)");
        String jokerKeuze = scanner.nextLine().toLowerCase();
        
        if (jokerKeuze.equals("hint")) {
            speler.setJoker(new HintJoker());  // ← Hard-coded joker instantiatie
        } else if (jokerKeuze.equals("sleutel")) {
            speler.setJoker(new SleutelJoker());  // ← Hard-coded joker instantiatie
        }
    }
}
```

#### **DIP Schending Analyse**
- **Input coupling**: Direct gekoppeld aan `Scanner(System.in)`
- **Output coupling**: Direct gekoppeld aan `System.out`
- **Factory coupling**: Hard-coded joker instantiatie
- **Niet testbaar**: Kan niet testen zonder console I/O
- **Niet flexibel**: Kan niet switchen naar GUI of web interface

---

### Schending 4: SpelerRepository.java - Ontbrekende Abstractie Laag

#### **Probleem Beschrijving**
Er is geen interface voor repository operaties, waardoor business logic direct gekoppeld is aan SQL implementatie details.

#### **Huidige Code**
```java
public class SpelerRepository {
    // Geen interface - directe SQL implementatie
    
    public void saveSpeler(Speler speler) {
        SQLHelper.executeUpdate("INSERT INTO speler (naam, huidige_kamer, status, scrum_kennis) VALUES (?, ?, ?, ?)",
                statement -> {
                    statement.setString(1, speler.getNaam());
                    statement.setInt(2, speler.getHuidigeKamer());
                    statement.setString(3, speler.getStatus());
                    statement.setInt(4, speler.getScrumKennis());
                });
    }
    
    public void updateScrumKennis(String naam, int scrumKennis) {
        SQLHelper.executeUpdate("UPDATE speler SET scrum_kennis = ? WHERE naam = ?",
                statement -> {
                    statement.setInt(1, scrumKennis);
                    statement.setString(2, naam);
                });
    }
}
```

#### **DIP Schending Analyse**
- **Geen abstractie**: Business logic gekoppeld aan SQL details
- **Niet uitwisselbaar**: Kan niet switchen naar NoSQL, file storage, etc.
- **Niet testbaar**: Vereist echte database voor tests
- **Tight coupling**: SQL wijzigingen breken business logic

---

### Schending 5: Kamer.java - Scanner Afhankelijkheid

#### **Probleem Beschrijving**
Kamer klassen gebruiken direct `Scanner` voor user input, wat UI concerns mengt met business logic.

#### **Huidige Code**
```java
public abstract class Kamer implements JokerAcceptor {
    protected VraagStrategie vraag;
    protected Monster monster;
    
    public void stelVraag() {
        Scanner scanner = new Scanner(System.in);  // ← Hard-coded input
        vraag.toonVraag();
        
        System.out.print("Jouw antwoord: ");
        String antwoord = scanner.nextLine();  // ← Direct console koppeling
        
        if (vraag.controleerAntwoord(antwoord)) {
            System.out.println(vraag.positieveFeedback());  // ← Hard-coded output
            monster.versla(Spel.getHuidigeSpeler());
        } else {
            System.out.println(vraag.negatieveFeedback());  // ← Hard-coded output
            Spel.getHuidigeSpeler().verlaagScrumKennis(monster.getLevenspunten());
        }
    }
}
```

#### **DIP Schending Analyse**
- **UI/Business mixing**: Input/output logic in business klasse
- **Niet testbaar**: Vereist console interactie
- **Niet herbruikbaar**: Kan niet gebruiken in GUI/web context
- **Multiple responsibilities**: Kamer doet zowel business logic als UI

---

## 3. Concrete Oplossingsstrategieën {#oplossingen}

### Oplossing 1: Repository Interface Pattern

#### **Nieuwe Abstractie Laag**
```java
// ISpelerRepository.java - Abstractie
public interface ISpelerRepository {
    void save(Speler speler);
    void updatePosition(String naam, int position);
    void updateScrumKennis(String naam, int kennis);
    SpelerData load(String naam);
    Set<Integer> getBezochteKamers(String naam);
}

// SpelerData.java - Data Transfer Object
public class SpelerData {
    private final String naam;
    private final int huidigeKamer;
    private final String status;
    private final int scrumKennis;
    private final Set<Integer> bezochteKamers;
    
    public SpelerData(String naam, int huidigeKamer, String status, int scrumKennis, Set<Integer> bezochteKamers) {
        this.naam = naam;
        this.huidigeKamer = huidigeKamer;
        this.status = status;
        this.scrumKennis = scrumKennis;
        this.bezochteKamers = new HashSet<>(bezochteKamers);
    }
    
    // Getters...
}
```

#### **Concrete Implementatie**
```java
// SQLSpelerRepository.java - Concrete implementatie
public class SQLSpelerRepository implements ISpelerRepository {
    @Override
    public void save(Speler speler) {
        SQLHelper.executeUpdate("INSERT INTO speler (naam, huidige_kamer, status, scrum_kennis) VALUES (?, ?, ?, ?)",
                statement -> {
                    statement.setString(1, speler.getNaam());
                    statement.setInt(2, speler.getHuidigeKamer());
                    statement.setString(3, speler.getStatus());
                    statement.setInt(4, speler.getScrumKennis());
                });
    }
    
    @Override
    public void updateScrumKennis(String naam, int kennis) {
        SQLHelper.executeUpdate("UPDATE speler SET scrum_kennis = ? WHERE naam = ?",
                statement -> {
                    statement.setInt(1, kennis);
                    statement.setString(2, naam);
                });
    }
    
    @Override
    public SpelerData load(String naam) {
        // SQL implementatie voor het laden van speler data
        return SQLHelper.executeSelect("SELECT * FROM speler WHERE naam = ?",
                statement -> statement.setString(1, naam),
                resultSet -> {
                    try {
                        if (resultSet.next()) {
                            return new SpelerData(
                                resultSet.getString("naam"),
                                resultSet.getInt("huidige_kamer"),
                                resultSet.getString("status"),
                                resultSet.getInt("scrum_kennis"),
                                getBezochteKamers(naam)
                            );
                        }
                        return null;
                    } catch (SQLException e) {
                        throw new RuntimeException("Fout bij laden speler", e);
                    }
                });
    }
    
    // ... andere implementaties
}

// InMemorySpelerRepository.java - Test implementatie
public class InMemorySpelerRepository implements ISpelerRepository {
    private final Map<String, SpelerData> spelers = new HashMap<>();
    
    @Override
    public void save(Speler speler) {
        SpelerData data = new SpelerData(
            speler.getNaam(),
            speler.getHuidigeKamer(),
            speler.getStatus(),
            speler.getScrumKennis(),
            speler.getBezochteKamers()
        );
        spelers.put(speler.getNaam(), data);
    }
    
    @Override
    public void updateScrumKennis(String naam, int kennis) {
        SpelerData existing = spelers.get(naam);
        if (existing != null) {
            SpelerData updated = new SpelerData(
                existing.getNaam(),
                existing.getHuidigeKamer(),
                existing.getStatus(),
                kennis,
                existing.getBezochteKamers()
            );
            spelers.put(naam, updated);
        }
    }
    
    // ... andere implementaties
}
```

#### **Refactored Speler Klasse**
```java
public class Speler {
    private String naam;
    private int huidigeKamer;
    private String status;
    private int scrumKennis;
    private final ISpelerRepository repository;  // ← Interface afhankelijkheid
    private Set<Integer> bezochteKamers;
    private List<VoortgangsMonitor> observers;
    private Joker joker;
    private int aantalSleutels;

    // Dependency Injection via constructor
    public Speler(String naam, ISpelerRepository repository) {
        this.naam = naam;
        this.repository = repository;  // ← Geïnjecteerde afhankelijkheid
        this.huidigeKamer = 0;
        this.status = "Begonnen";
        this.scrumKennis = 0;
        this.bezochteKamers = new HashSet<>();
        this.bezochteKamers.add(0);
        this.observers = new ArrayList<>();
        
        repository.save(this);  // ← Gebruik van abstractie
    }
    
    public void verhoogScrumKennis(int aantal) {
        this.scrumKennis += aantal;
        System.out.println("Scrum kennis van " + naam + " verhoogd met " + aantal);
        
        repository.updateScrumKennis(this.naam, this.scrumKennis);  // ← Interface gebruik
        notifyObservers();
    }
    
    public void loadFromRepository() {
        SpelerData data = repository.load(this.naam);
        if (data != null) {
            this.huidigeKamer = data.getHuidigeKamer();
            this.status = data.getStatus();
            this.scrumKennis = data.getScrumKennis();
            this.bezochteKamers = new HashSet<>(data.getBezochteKamers());
            
            notifyObservers();
        }
    }
    
    // ... rest van implementatie blijft hetzelfde
}
```

---

### Oplossing 2: Service Locator Pattern voor Game Context

#### **Game Context Interface**
```java
// ISpelContext.java - Abstractie voor game state
public interface ISpelContext {
    Speler getHuidigeSpeler();
    void setHuidigeSpeler(Speler speler);
    List<Kamer> getKamers();
    void voegKamerToe(Kamer kamer);
    boolean isSpelActief();
    void beeindigSpel();
}

// SpelContext.java - Concrete implementatie
public class SpelContext implements ISpelContext {
    private Speler huidigeSpeler;
    private List<Kamer> kamers;
    private boolean spelActief;
    
    public SpelContext() {
        this.kamers = new ArrayList<>();
        this.spelActief = true;
    }
    
    @Override
    public Speler getHuidigeSpeler() {
        return huidigeSpeler;
    }
    
    @Override
    public void setHuidigeSpeler(Speler speler) {
        this.huidigeSpeler = speler;
    }
    
    @Override
    public List<Kamer> getKamers() {
        return new ArrayList<>(kamers);  // Defensive copy
    }
    
    @Override
    public void voegKamerToe(Kamer kamer) {
        kamers.add(kamer);
    }
    
    @Override
    public boolean isSpelActief() {
        return spelActief;
    }
    
    @Override
    public void beeindigSpel() {
        this.spelActief = false;
    }
}
```

#### **Refactored SleutelJoker**
```java
public class SleutelJoker extends Joker {
    private final ISpelContext spelContext;  // ← Interface afhankelijkheid
    
    // Dependency Injection via constructor
    public SleutelJoker(ISpelContext spelContext) {
        this.spelContext = spelContext;  // ← Geïnjecteerde afhankelijkheid
    }
    
    @Override
    public boolean kanGebruiktWordenIn(Kamer kamer) {
        return kamer instanceof KamerDaily || kamer instanceof KamerReview;
    }

    @Override
    protected void doeGebruikIn(Kamer kamer) {
        System.out.println("🔑 Sleutel Joker geactiveerd!");
        Speler speler = spelContext.getHuidigeSpeler();  // ← Interface gebruik
        
        if (speler != null) {
            kamer.geefExtraSleutel(speler);
            System.out.println("Je hebt nu " + speler.getAantalSleutels() + " sleutels.");
        } else {
            System.out.println("Geen actieve speler gevonden.");
        }
    }

    @Override
    public String beschrijving() {
        return "Dit is een Sleutel Joker. Je kan deze joker gebruiken om een extra sleutel te krijgen in de Daily Scrum of Review kamer.";
    }
}
```

---

### Oplossing 3: Input/Output Abstraction

#### **I/O Interfaces**
```java
// IInputProvider.java - Input abstractie
public interface IInputProvider {
    String readLine();
    String readLine(String prompt);
    void close();
}

// IOutputProvider.java - Output abstractie
public interface IOutputProvider {
    void println(String message);
    void print(String message);
    void printError(String error);
}

// ConsoleInputProvider.java - Console implementatie
public class ConsoleInputProvider implements IInputProvider {
    private final Scanner scanner;
    
    public ConsoleInputProvider() {
        this.scanner = new Scanner(System.in);
    }
    
    @Override
    public String readLine() {
        return scanner.nextLine();
    }
    
    @Override
    public String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }
    
    @Override
    public void close() {
        scanner.close();
    }
}

// ConsoleOutputProvider.java - Console implementatie
public class ConsoleOutputProvider implements IOutputProvider {
    @Override
    public void println(String message) {
        System.out.println(message);
    }
    
    @Override
    public void print(String message) {
        System.out.print(message);
    }
    
    @Override
    public void printError(String error) {
        System.err.println("ERROR: " + error);
    }
}

// TestInputProvider.java - Test implementatie
public class TestInputProvider implements IInputProvider {
    private final Queue<String> inputs;
    
    public TestInputProvider(String... inputs) {
        this.inputs = new LinkedList<>(Arrays.asList(inputs));
    }
    
    @Override
    public String readLine() {
        return inputs.poll();
    }
    
    @Override
    public String readLine(String prompt) {
        return readLine();
    }
    
    @Override
    public void close() {
        // Nothing to close
    }
}
```

#### **Refactored Spel Klasse**
```java
public class Spel {
    private String spelNaam;
    private final ISpelContext spelContext;
    private final IInputProvider inputProvider;
    private final IOutputProvider outputProvider;
    private final IJokerFactory jokerFactory;
    private final ISpelerRepository spelerRepository;

    // Dependency Injection via constructor
    public Spel(String spelNaam, 
                ISpelContext spelContext,
                IInputProvider inputProvider, 
                IOutputProvider outputProvider,
                IJokerFactory jokerFactory,
                ISpelerRepository spelerRepository) {
        this.spelNaam = spelNaam;
        this.spelContext = spelContext;
        this.inputProvider = inputProvider;
        this.outputProvider = outputProvider;
        this.jokerFactory = jokerFactory;
        this.spelerRepository = spelerRepository;
    }
    
    public void start() throws SQLException {
        outputProvider.println("Welkom bij " + spelNaam + "!");
        String naam = inputProvider.readLine("Voer je naam in: ");
        
        Speler speler = new Speler(naam, spelerRepository);
        spelContext.setHuidigeSpeler(speler);
        
        kiesJoker(speler);
        speler.verplaats(0);

        while (spelContext.isSpelActief()) {
            List<Kamer> kamers = spelContext.getKamers();
            if (speler.getHuidigeKamer() < kamers.size()) {
                Kamer huidigeKamer = kamers.get(speler.getHuidigeKamer());
                huidigeKamer.betreed();
            }
            
            String input = inputProvider.readLine("> ");
            verwerkCommando(input, speler);
        }
    }

    public void kiesJoker(Speler speler) {
        outputProvider.println("Wil je een HintJoker of een SleutelJoker? (hint/sleutel)");
        String jokerKeuze = inputProvider.readLine().toLowerCase();
        
        if (speler.getJoker() != null) {
            outputProvider.println("Je hebt al een joker toegewezen gekregen.");
            return;
        }

        try {
            Joker joker = jokerFactory.createJoker(jokerKeuze, spelContext);  // ← Factory gebruik
            if (joker != null) {
                speler.setJoker(joker);
                outputProvider.println(joker.beschrijving());
                outputProvider.println("Je kunt de joker later gebruiken met het commando 'gebruik joker'.");
            } else {
                outputProvider.println("Ongeldige keuze, geen joker toegewezen.");
            }
        } catch (Exception e) {
            outputProvider.printError("Fout bij het maken van joker: " + e.getMessage());
        }
    }
    
    // ... rest van implementatie
}
```

---

### Oplossing 4: Factory Pattern voor Joker Creatie

#### **Joker Factory Interface**
```java
// IJokerFactory.java - Factory abstractie
public interface IJokerFactory {
    Joker createJoker(String type, ISpelContext spelContext);
    List<String> getAvailableJokerTypes();
}

// JokerFactory.java - Concrete factory
public class JokerFactory implements IJokerFactory {
    @Override
    public Joker createJoker(String type, ISpelContext spelContext) {
        switch (type.toLowerCase()) {
            case "hint":
                return new HintJoker();
            case "sleutel":
                return new SleutelJoker(spelContext);  // ← Dependency injection
            default:
                return null;
        }
    }
    
    @Override
    public List<String> getAvailableJokerTypes() {
        return Arrays.asList("hint", "sleutel");
    }
}

// TestJokerFactory.java - Test factory
public class TestJokerFactory implements IJokerFactory {
    private final Map<String, Joker> predefinedJokers;
    
    public TestJokerFactory() {
        this.predefinedJokers = new HashMap<>();
    }
    
    public void addJoker(String type, Joker joker) {
        predefinedJokers.put(type.toLowerCase(), joker);
    }
    
    @Override
    public Joker createJoker(String type, ISpelContext spelContext) {
        return predefinedJokers.get(type.toLowerCase());
    }
    
    @Override
    public List<String> getAvailableJokerTypes() {
        return new ArrayList<>(predefinedJokers.keySet());
    }
}
```

---

### Oplossing 5: Kamer I/O Abstraction

#### **Kamer Interface Refactoring**
```java
// IUserInteractionService.java - UI abstractie
public interface IUserInteractionService {
    String askQuestion(String question);
    void showMessage(String message);
    void showError(String error);
    boolean askForConfirmation(String question);
}

// ConsoleUserInteractionService.java - Console implementatie
public class ConsoleUserInteractionService implements IUserInteractionService {
    private final IInputProvider inputProvider;
    private final IOutputProvider outputProvider;
    
    public ConsoleUserInteractionService(IInputProvider inputProvider, IOutputProvider outputProvider) {
        this.inputProvider = inputProvider;
        this.outputProvider = outputProvider;
    }
    
    @Override
    public String askQuestion(String question) {
        return inputProvider.readLine(question + " ");
    }
    
    @Override
    public void showMessage(String message) {
        outputProvider.println(message);
    }
    
    @Override
    public void showError(String error) {
        outputProvider.printError(error);
    }
    
    @Override
    public boolean askForConfirmation(String question) {
        String answer = inputProvider.readLine(question + " (ja/nee): ");
        return answer.toLowerCase().startsWith("j");
    }
}
```

#### **Refactored Kamer Klasse**
```java
public abstract class Kamer implements JokerAcceptor {
    protected String beschrijving;
    protected VraagStrategie vraag;
    protected Monster monster;
    protected final IUserInteractionService userService;  // ← Interface afhankelijkheid
    protected final ISpelContext spelContext;  // ← Interface afhankelijkheid

    // Dependency Injection via constructor
    public Kamer(String beschrijving, IUserInteractionService userService, ISpelContext spelContext) {
        this.beschrijving = beschrijving;
        this.userService = userService;  // ← Geïnjecteerde afhankelijkheid
        this.spelContext = spelContext;  // ← Geïnjecteerde afhankelijkheid
    }

    public void stelVraag() {
        vraag.toonVraag();
        
        String antwoord = userService.askQuestion("Jouw antwoord:");  // ← Interface gebruik
        
        if (vraag.controleerAntwoord(antwoord)) {
            userService.showMessage(vraag.positieveFeedback());  // ← Interface gebruik
            Speler speler = spelContext.getHuidigeSpeler();  // ← Interface gebruik
            if (speler != null) {
                monster.versla(speler);
            }
        } else {
            userService.showMessage(vraag.negatieveFeedback());  // ← Interface gebruik
            Speler speler = spelContext.getHuidigeSpeler();  // ← Interface gebruik
            if (speler != null) {
                speler.verlaagScrumKennis(monster.getLevenspunten());
            }
        }
    }
    
    public void geefHint() {
        if (userService.askForConfirmation("Wil je een hint?")) {  // ← Interface gebruik
            userService.showMessage("💡 Hint: Denk aan de Scrum principes!");  // ← Interface gebruik
        }
    }
    
    // ... rest van implementatie
}
```

---

## 4. Implementatie Roadmap {#roadmap}

### Fase 1: Repository Pattern Foundation (Week 1-2)
**Prioriteit: Kritiek - Fundamentele DIP compliance**

#### Stap 1.1: Repository Interface Creatie
- [ ] Creëer `ISpelerRepository` interface
- [ ] Implementeer `SpelerData` DTO klasse
- [ ] Creëer `SQLSpelerRepository` concrete implementatie
- [ ] Creëer `InMemorySpelerRepository` voor testing
- [ ] **Geschatte tijd**: 6-8 uur

#### Stap 1.2: Speler Klasse Refactoring
- [ ] Refactor `Speler` constructor voor dependency injection
- [ ] Update alle `Speler` instantiaties in codebase
- [ ] Implementeer unit tests voor nieuwe repository pattern
- [ ] **Geschatte tijd**: 8-10 uur

### Fase 2: Service Locator Pattern (Week 2-3)
**Prioriteit: Hoog - Elimineer statische afhankelijkheden**

#### Stap 2.1: Game Context Interface
- [ ] Creëer `ISpelContext` interface
- [ ] Implementeer `SpelContext` concrete klasse
- [ ] Refactor `Spel` klasse om context te gebruiken
- [ ] **Geschatte tijd**: 4-6 uur

#### Stap 2.2: SleutelJoker Refactoring
- [ ] Refactor `SleutelJoker` voor dependency injection
- [ ] Update joker factory voor context injection
- [ ] Test joker functionaliteit met mocks
- [ ] **Geschatte tijd**: 3-4 uur

### Fase 3: I/O Abstraction (Week 3-4)
**Prioriteit: Medium - Verbeter testbaarheid**

#### Stap 3.1: Input/Output Interfaces
- [ ] Creëer `IInputProvider` en `IOutputProvider` interfaces
- [ ] Implementeer console en test providers
- [ ] Refactor `Spel` klasse voor I/O injection
- [ ] **Geschatte tijd**: 6-8 uur

#### Stap 3.2: Kamer I/O Refactoring
- [ ] Creëer `IUserInteractionService` interface
- [ ] Refactor `Kamer` klassen voor service injection
- [ ] Update alle kamer constructors
- [ ] **Geschatte tijd**: 8-10 uur

### Fase 4: Factory Pattern Implementation (Week 4-5)
**Prioriteit: Medium - Elimineer hard-coded instantiaties**

#### Stap 4.1: Joker Factory
- [ ] Creëer `IJokerFactory` interface
- [ ] Implementeer concrete en test factories
- [ ] Integreer factory in `Spel` klasse
- [ ] **Geschatte tijd**: 4-6 uur

### Fase 5: Testing & Validation (Week 5)
**Prioriteit: Hoog - Valideer DIP compliance**

#### Stap 5.1: Comprehensive Testing
- [ ] Unit tests voor alle nieuwe interfaces
- [ ] Integration tests voor dependency injection
- [ ] Mock-based testing voor alle afhankelijkheden
- [ ] **Geschatte tijd**: 8-12 uur

#### Stap 5.2: Code Review & Documentation
- [ ] Code review voor DIP compliance
- [ ] Update documentatie en comments
- [ ] Performance impact analyse
- [ ] **Geschatte tijd**: 4-6 uur

**Totale geschatte tijd**: 55-80 uur over 5 weken

---

## 5. Voor/Na Code Vergelijkingen {#vergelijkingen}

### Vergelijking 1: Speler Klasse

#### **Voor (DIP Schending)**
```java
public class Speler {
    private SpelerRepository repository;  // ← Concrete afhankelijkheid
    
    public Speler(String naam) {
        this.repository = new SpelerRepository();  // ← Hard-coded
        repository.saveSpeler(this);
    }
    
    public void verhoogScrumKennis(int aantal) {
        this.scrumKennis += aantal;
        repository.updateScrumKennis(this.naam, this.scrumKennis);  // ← Tight coupling
    }
}

// Gebruik:
Speler speler = new Speler("Test");  // ← Maakt database connectie
```

#### **Na (DIP Compliant)**
```java
public class Speler {
    private final ISpelerRepository repository;  // ← Interface afhankelijkheid
    
    public Speler(String naam, ISpelerRepository repository) {
        this.repository = repository;  // ← Geïnjecteerd
        repository.save(this);
    }
    
    public void verhoogScrumKennis(int aantal) {
        this.scrumKennis += aantal;
        repository.updateScrumKennis(this.naam, this.scrumKennis);  // ← Loose coupling
    }
}

// Gebruik:
ISpelerRepository repo = new SQLSpelerRepository();  // ← Of InMemorySpelerRepository voor tests
Speler speler = new Speler("Test", repo);  // ← Flexibel en testbaar
```

**Voordelen:**
- ✅ **Testbaar**: Kan InMemoryRepository gebruiken voor tests
- ✅ **Flexibel**: Kan switchen tussen SQL, NoSQL, file storage
- ✅ **Loose coupling**: Speler hangt niet af van concrete repository
- ✅ **Mockable**: Repository kan gemockt worden voor unit tests

---

### Vergelijking 2: SleutelJoker Klasse

#### **Voor (DIP Schending)**
```java
public class SleutelJoker extends Joker {
    @Override
    protected void doeGebruikIn(Kamer kamer) {
        Speler speler = Spel.getHuidigeSpeler();  // ← Statische afhankelijkheid
        kamer.geefExtraSleutel(speler);
    }
}

// Test probleem:
@Test
public void testSleutelJoker() {
    SleutelJoker joker = new SleutelJoker();
    // Kan niet testen zonder Spel.setHuidigeSpeler() te callen
}
```

#### **Na (DIP Compliant)**
```java
public class SleutelJoker extends Joker {
    private final ISpelContext spelContext;  // ← Interface afhankelijkheid
    
    public SleutelJoker(ISpelContext spelContext) {
        this.spelContext = spelContext;  // ← Geïnjecteerd
    }
    
    @Override
    protected void doeGebruikIn(Kamer kamer) {
        Speler speler = spelContext.getHuidigeSpeler();  // ← Interface gebruik
        if (speler != null) {
            kamer.geefExtraSleutel(speler);
        }
    }
}

// Test oplossing:
@Test
public void testSleutelJoker() {
    ISpelContext mockContext = mock(ISpelContext.class);
    Speler testSpeler = new Speler("Test", mockRepo);
    when(mockContext.getHuidigeSpeler()).thenReturn(testSpeler);
    
    SleutelJoker joker = new SleutelJoker(mockContext);  // ← Volledig testbaar
    // Test kan nu geïsoleerd draaien
}
```

**Voordelen:**
- ✅ **Testbaar**: Kan mock context gebruiken
- ✅ **Geen verborgen afhankelijkheden**: Alles expliciet in constructor
- ✅ **Flexibel**: Kan verschillende context implementaties gebruiken
- ✅ **Isolated testing**: Tests beïnvloeden elkaar niet

---

### Vergelijking 3: Spel Klasse

#### **Voor (DIP Schending)**
```java
public class Spel {
    private Scanner scanner;  // ← Concrete I/O
    
    public Spel(String spelNaam) {
        this.scanner = new Scanner(System.in);  // ← Hard-coded
    }
    
    public void start() {
        System.out.println("Welkom!");  // ← Hard-coded output
        String naam = scanner.nextLine();  // ← Console gekoppeld
        
        if (jokerKeuze.equals("hint")) {
            speler.setJoker(new HintJoker());  // ← Hard-coded instantiatie
        }
    }
}
```

#### **Na (DIP Compliant)**
```java
public class Spel {
    private final IInputProvider inputProvider;   // ← Interface afhankelijkheden
    private final IOutputProvider outputProvider;
    private final IJokerFactory jokerFactory;
    private final ISpelContext spelContext;
    
    public Spel(String spelNaam, 
                IInputProvider inputProvider,
                IOutputProvider outputProvider,
                IJokerFactory jokerFactory,
                ISpelContext spelContext) {
        this.inputProvider = inputProvider;      // ← Geïnjecteerd
        this.outputProvider = outputProvider;
        this.jokerFactory = jokerFactory;
        this.spelContext = spelContext;
    }
    
    public void start() {
        outputProvider.println("Welkom!");       // ← Interface gebruik
        String naam = inputProvider.readLine("Naam: ");
        
        Joker joker = jokerFactory.createJoker(jokerKeuze, spelContext);  // ← Factory gebruik
        speler.setJoker(joker);
    }
}
```

**Voordelen:**
- ✅ **UI Agnostic**: Kan console, GUI, web interface gebruiken
- ✅ **Testbaar**: Kan test I/O providers gebruiken
- ✅ **Flexibel**: Factory kan verschillende joker implementaties maken
- ✅ **Separation of Concerns**: Business logic gescheiden van I/O

---

## 6. Testing Strategieën {#testing}

### Unit Testing met Dependency Injection

#### **Repository Testing**
```java
@Test
public void testSpelerScrumKennisVerhoging() {
    // Arrange
    ISpelerRepository mockRepo = mock(ISpelerRepository.class);
    Speler speler = new Speler("TestSpeler", mockRepo);
    
    // Act
    speler.verhoogScrumKennis(10);
    
    // Assert
    assertEquals(10, speler.getScrumKennis());
    verify(mockRepo).updateScrumKennis("TestSpeler", 10);
}

@Test
public void testSpelerRepositoryIntegration() {
    // Arrange
    ISpelerRepository inMemoryRepo = new InMemorySpelerRepository();
    Speler speler = new Speler("IntegrationTest", inMemoryRepo);
    
    // Act
    speler.verhoogScrumKennis(15);
    SpelerData data = inMemoryRepo.load("IntegrationTest");
    
    // Assert
    assertEquals(15, data.getScrumKennis());
}
```

#### **Joker Testing met Context**
```java
@Test
public void testSleutelJokerMetMockContext() {
    // Arrange
    ISpelContext mockContext = mock(ISpelContext.class);
    Speler mockSpeler = mock(Speler.class);
    Kamer mockKamer = mock(KamerDaily.class);
    
    when(mockContext.getHuidigeSpeler()).thenReturn(mockSpeler);
    when(mockSpeler.getAantalSleutels()).thenReturn(5);
    
    SleutelJoker joker = new SleutelJoker(mockContext);
    
    // Act
    joker.gebruikIn(mockKamer);
    
    // Assert
    verify(mockKamer).geefExtraSleutel(mockSpeler);
}

@Test
public void testSleutelJokerZonderSpeler() {
    // Arrange
    ISpelContext mockContext = mock(ISpelContext.class);
    when(mockContext.getHuidigeSpeler()).thenReturn(null);
    
    SleutelJoker joker = new SleutelJoker(mockContext);
    Kamer mockKamer = mock(KamerDaily.class);
    
    // Act
    joker.gebruikIn(mockKamer);
    
    // Assert
    verify(mockKamer, never()).geefExtraSleutel(any());
}
```

#### **I/O Testing**
```java
@Test
public void testSpelStartMetTestInput() {
    // Arrange
    TestInputProvider testInput = new TestInputProvider("TestSpeler", "hint");
    TestOutputProvider testOutput = new TestOutputProvider();
    IJokerFactory mockFactory = mock(IJokerFactory.class);
    ISpelContext mockContext = mock(ISpelContext.class);
    ISpelerRepository mockRepo = mock(ISpelerRepository.class);
    
    when(mockFactory.createJoker("hint", mockContext)).thenReturn(new HintJoker());
    
    Spel spel = new Spel("TestSpel", mockContext, testInput, testOutput, mockFactory, mockRepo);
    
    // Act
    spel.kiesJoker(new Speler("TestSpeler", mockRepo));
    
    // Assert
    assertTrue(testOutput.getMessages().contains("Dit is een hint joker"));
    verify(mockFactory).createJoker("hint", mockContext);
}
```

### Integration Testing

#### **End-to-End DIP Testing**
```java
@Test
public void testCompleteSpelMetDependencyInjection() {
    // Arrange - Maak alle dependencies
    ISpelerRepository inMemoryRepo = new InMemorySpelerRepository();
    ISpelContext spelContext = new SpelContext();
    TestInputProvider testInput = new TestInputProvider("TestSpeler", "hint", "ga naar kamer 1", "stop");
    TestOutputProvider testOutput = new TestOutputProvider();
    IJokerFactory jokerFactory = new JokerFactory();
    
    // Maak test kamers
    IUserInteractionService userService = new TestUserInteractionService(testInput, testOutput);
    Kamer kamer1 = new KamerDaily("Test Daily", userService, spelContext);
    spelContext.voegKamerToe(kamer1);
    
    Spel spel = new Spel("TestSpel", spelContext, testInput, testOutput, jokerFactory, inMemoryRepo);
    
    // Act
    spel.start();
    
    // Assert
    Speler speler = spelContext.getHuidigeSpeler();
    assertNotNull(speler);
    assertEquals("TestSpeler", speler.getNaam());
    assertNotNull(speler.getJoker());
    assertTrue(speler.getJoker() instanceof HintJoker);
    
    // Verify repository was used
    SpelerData data = inMemoryRepo.load("TestSpeler");
    assertNotNull(data);
}
```

### Performance Testing

#### **Dependency Injection Overhead**
```java
@Test
public void testDependencyInjectionPerformance() {
    // Measure creation time with DI
    long startTime = System.nanoTime();
    
    for (int i = 0; i < 1000; i++) {
        ISpelerRepository repo = new InMemorySpelerRepository();
        Speler speler = new Speler("Test" + i, repo);
    }
    
    long endTime = System.nanoTime();
    long duration = endTime - startTime;
    
    // Assert reasonable performance (adjust threshold as needed)
    assertTrue("DI should not add significant overhead", duration < 100_000_000); // 100ms
}
```

---

## 7. Conclusie {#conclusie}

### Huidige DIP Status
De codebase bevat **5 significante DIP schendingen** die de testbaarheid, flexibiliteit en maintainability ernstig beperken:

1. **Speler.java**: Hard-coded repository afhankelijkheid
2. **SleutelJoker.java**: Statische afhankelijkheid naar Spel klasse
3. **Spel.java**: Concrete I/O afhankelijkheden
4. **SpelerRepository.java**: Ontbrekende abstractie laag
5. **Kamer.java**: UI/Business logic vermenging

### Impact van DIP Schendingen

#### **Technische Problemen**
- ❌ **Niet testbaar**: Unit tests vereisen database/console
- ❌ **Tight coupling**: Wijzigingen propageren door hele systeem
- ❌ **Niet flexibel**: Kan niet switchen tussen implementaties
- ❌ **Moeilijk te mocken**: Statische afhankelijkheden blokkeren mocking

#### **Ontwikkelings Problemen**
- ❌ **Langzame tests**: Database/I/O operaties in unit tests
- ❌ **Fragiele tests**: Tests breken door infrastructure wijzigingen
- ❌ **Moeilijke debugging**: Afhankelijkheden zijn verborgen
- ❌ **Beperkte herbruikbaarheid**: Code is gekoppeld aan specifieke implementaties

### Voordelen van DIP Implementatie

#### **Technische Voordelen**
- ✅ **Testbaarheid**: Alle klassen unit testbaar met mocks
- ✅ **Flexibiliteit**: Kan switchen tussen SQL, NoSQL, file storage
- ✅ **Loose coupling**: Modules zijn onafhankelijk van implementatie details
- ✅ **Mockability**: Alle afhankelijkheden kunnen gemockt worden

#### **Ontwikkelings Voordelen**
- ✅ **Snelle tests**: Unit tests draaien zonder I/O
- ✅ **Robuuste tests**: Tests zijn geïsoleerd van infrastructure
- ✅ **Duidelijke afhankelijkheden**: Alle dependencies expliciet in constructors
- ✅ **Herbruikbare componenten**: Business logic onafhankelijk van UI/database

#### **Architecturale Voordelen**
- ✅ **Separation of Concerns**: Business logic gescheiden van infrastructure
- ✅ **Inversion of Control**: Dependencies worden van buitenaf geïnjecteerd
- ✅ **Plugin Architecture**: Nieuwe implementaties zonder code wijzigingen
- ✅ **Configuration flexibility**: Runtime configuratie van dependencies

### Implementatie Prioriteiten

#### **Fase 1 (Kritiek)**: Repository Pattern
- **Impact**: Hoog - Maakt business logic testbaar
- **Effort**: Medium - Vereist interface extractie en constructor wijzigingen
- **ROI**: Zeer hoog - Fundamentele verbetering in code kwaliteit

#### **Fase 2 (Hoog)**: Service Locator Pattern
- **Impact**: Medium - Elimineert statische afhankelijkheden
- **Effort**: Low - Relatief eenvoudige interface extractie
- **ROI**: Hoog - Grote verbetering in testbaarheid

#### **Fase 3 (Medium)**: I/O Abstraction
- **Impact**: Medium - Maakt UI-agnostic development mogelijk
- **Effort**: Medium - Vereist interface design en refactoring
- **ROI**: Medium - Verbetert flexibiliteit en testbaarheid

### Success Metrics

#### **Code Quality Metrics**
- **Test Coverage**: Target >90% voor business logic
- **Coupling Metrics**: Afferent/Efferent coupling <5
- **Dependency Direction**: Alle dependencies wijzen naar abstracties
- **Mock Usage**: >80% van tests gebruiken mocks

#### **Development Metrics**
- **Test Execution Time**: Unit tests <1 seconde
- **Build Time**: Geen significante impact door DI
- **Bug Reduction**: 50% minder coupling-gerelateerde bugs
- **Feature Development Speed**: 30% sneller door betere testbaarheid

### Lange Termijn Visie

#### **Architecturale Evolutie**
1. **IoC Container**: Overweeg Spring/Guice voor automatische DI
2. **Configuration Management**: Externalize dependency configuration
3. **Plugin System**: Enable runtime component swapping
4. **Microservices Ready**: Architecture supports service decomposition

#### **Team Development**
1. **DI Training**: Team training over dependency injection patterns
2. **Code Review Guidelines**: DIP compliance in review criteria
3. **Architecture Documentation**: Document dependency flow en injection points
4. **Best Practices**: Establish team standards voor DI implementation

### Aanbevelingen

#### **Onmiddellijke Acties**
1. **Start met Repository Pattern** - Hoogste impact op testbaarheid
2. **Implementeer InMemoryRepository** - Voor snelle test feedback
3. **Refactor Speler constructor** - Fundamentele DIP compliance

#### **Korte Termijn (1-2 maanden)**
1. **Service Locator implementatie** - Elimineer statische dependencies
2. **I/O abstraction** - Maak UI-agnostic development mogelijk
3. **Comprehensive testing** - Valideer alle DIP improvements

#### **Lange Termijn (3-6 maanden)**
1. **IoC Container evaluatie** - Voor automatische dependency management
2. **Architecture review** - Assess overall SOLID compliance
3. **Performance optimization** - Fine-tune DI overhead

Door deze DIP implementatie zal de codebase transformeren van een tightly-coupled, moeilijk testbare applicatie naar een flexibele, maintainable en thoroughly testable system. De investering in refactoring zal zich snel terugbetalen door snellere development cycles, minder bugs en betere code quality.
