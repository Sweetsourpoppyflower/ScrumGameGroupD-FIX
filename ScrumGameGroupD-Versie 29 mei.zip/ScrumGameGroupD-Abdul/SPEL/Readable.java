public abstract class Readable {
    void showMessage(String message) {
        System.out.println("Dit is een interactief object.");
    }

}
