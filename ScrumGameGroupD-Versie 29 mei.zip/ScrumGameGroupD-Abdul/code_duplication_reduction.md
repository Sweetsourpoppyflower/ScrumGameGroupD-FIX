# Code Duplicatie Vermindering

## Overzicht
Dit document beschrijft de duplicaties die zijn gevonden in het ScrumGameGroupD project en de acties die zijn ondernomen om deze duplicaties te verminderen. Door duplicatie te verminderen wordt de code eenvoudiger te onderhouden en minder foutgevoelig.

## Geïdentificeerde Duplicaties en Oplossingen

### 1. Monster Implementaties

#### Probleem
De klassen `Zombie.java`, `Draak.java`, en `Reuzenspin.java` bevatten vrijwel identieke code voor:
- De `ontvangSchade` methode
- De `getLevenspunten` methode
- Grote delen van de `versla` methode

#### Oplossing
- `Monster` is omgezet van een interface naar een abstracte klasse
- Gemeenschappelijke code is verplaatst naar de abstracte `Monster` klasse:
  - `ontvangSchade` methode
  - `getLevenspunten` methode
  - Standaard implementatie van `versla` methode
- Specifieke monster klassen erven nu van de abstracte `Monster` klasse en implementeren alleen nog de specifieke methoden:
  - `aanval`
  - `getNaam`
  - `beschrijving`
- De `Zombie` klasse heeft een aangepaste `versla` methode behouden omdat deze een andere melding toont

### 2. Kamer Implementaties

#### Probleem
De verschillende kamerklassen (`KamerReview.java`, `KamerDaily.java`, `KamerRetro.java`, `KamerPlanning.java`, `KamerBacklog.java`) bevatten veel duplicatie in:
- De `stelVraag` methode (vrijwel identiek in alle kamers)
- De `vraagOmHint` methode (identiek in alle kamers)
- De `geefExtraSleutel` methode (bijna identiek, alleen de kamernaam verschilt)
- De `betreed` methode (vergelijkbare structuur)

#### Oplossing
- De abstracte `Kamer` klasse is uitgebreid met:
  - Gemeenschappelijke velden `vraag` en `monster`
  - Een nieuwe abstracte methode `getKamerNaam()` die door subklassen wordt geïmplementeerd
  - Een gemeenschappelijke implementatie van `geefExtraSleutel` die de kamernaam dynamisch ophaalt
  - Gemeenschappelijke implementaties van `stelVraag` en `vraagOmHint`
- Alle kamerklassen zijn aangepast om:
  - De nieuwe abstracte methode `getKamerNaam()` te implementeren
  - De gedupliceerde methoden te verwijderen die nu in de abstracte klasse staan
  - Alleen de specifieke functionaliteit te behouden

### 3. Joker Acceptatie

#### Probleem
De `accepteer` methode in verschillende kamers was inconsistent geïmplementeerd:
- Sommige kamers hadden een lege implementatie
- Andere kamers hadden een aangepaste implementatie
- Sommige kamers gebruikten de standaard implementatie van de interface

#### Oplossing
- De standaard implementatie van `accepteer` is verplaatst naar de abstracte `Kamer` klasse
- Alleen `KamerBacklog` heeft een aangepaste implementatie behouden omdat deze extra validatie uitvoert

## Voordelen van de Wijzigingen

1. **Verbeterde Onderhoudbaarheid**: Wijzigingen hoeven slechts op één plaats te worden aangebracht in plaats van in meerdere klassen
2. **Verminderde Foutgevoeligheid**: Minder duplicatie betekent minder kans op inconsistenties bij toekomstige wijzigingen
3. **Betere Leesbaarheid**: De code is nu beter gestructureerd en volgt het DRY (Don't Repeat Yourself) principe
4. **Eenvoudiger Uitbreidbaarheid**: Nieuwe monsters of kamers kunnen eenvoudiger worden toegevoegd door te erven van de abstracte klassen

## Conclusie

Door het toepassen van object-georiënteerde principes zoals overerving en het gebruik van abstracte klassen, is de hoeveelheid gedupliceerde code in het project aanzienlijk verminderd. Dit maakt de code robuuster, beter onderhoudbaar en minder foutgevoelig.
