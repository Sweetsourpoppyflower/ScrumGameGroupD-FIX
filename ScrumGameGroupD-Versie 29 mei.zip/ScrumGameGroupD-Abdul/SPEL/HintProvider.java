public interface HintProvider {
    String getHint();
}
