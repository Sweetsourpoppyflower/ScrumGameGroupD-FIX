# ISP and SRP Implementation Plan for Java Game Codebase

## Overview
This document provides a comprehensive analysis and implementation plan for applying **ISP (Interface Segregation Principle)** and **SRP (Single Responsibility Principle)** to your Java game codebase.

---

## 🔴 SRP (Single Responsibility Principle) Violations

### 1. **`SPEL/Speler.java`** - CRITICAL VIOLATION ⚠️

**Current Responsibilities:**
- Player state management (position, status, scrum knowledge)
- Database persistence operations via SpelerRepository
- Observer pattern implementation (managing observers list)
- Joker management (setting/getting jokers)
- Visited rooms tracking
- Key management

**Problems:**
- Too many reasons to change (game logic, database schema, observer pattern, joker system)
- Violates SRP by mixing business logic with persistence and infrastructure concerns
- Hard to test individual responsibilities in isolation

**Recommended Refactoring:**

```java
// 1. SpelerState.java - Core player data
public class SpelerState {
    private String naam;
    private int huidigeKamer;
    private String status;
    private int scrumKennis;
    private int aantalSleutels;
    
    // Basic getters/setters and state management
}

// 2. SpelerPersistence.java - Database operations
public class SpelerPersistence {
    private SpelerRepository repository;
    
    public void save(SpelerState state) { }
    public SpelerState load(String naam) { }
    public void updatePosition(String naam, int position) { }
    public void updateScrumKennis(String naam, int kennis) { }
}

// 3. SpelerObservable.java - Observer pattern
public class SpelerObservable {
    private List<VoortgangsMonitor> observers;
    
    public void registerObserver(VoortgangsMonitor observer) { }
    public void removeObserver(VoortgangsMonitor observer) { }
    public void notifyObservers(SpelerState state) { }
}

// 4. JokerManager.java - Joker handling
public class JokerManager {
    private Joker currentJoker;
    
    public void setJoker(Joker joker) { }
    public Joker getJoker() { }
    public boolean hasJoker() { }
}

// 5. RoomTracker.java - Room tracking
public class RoomTracker {
    private Set<Integer> bezochteKamers;
    
    public void addVisitedRoom(int roomId) { }
    public boolean isRoomVisited(int roomId) { }
    public Set<Integer> getVisitedRooms() { }
}

// 6. Refactored Speler.java - Composition root
public class Speler {
    private SpelerState state;
    private SpelerPersistence persistence;
    private SpelerObservable observable;
    private JokerManager jokerManager;
    private RoomTracker roomTracker;
    
    // Delegates to appropriate components
}
```

### 2. **`SPEL/Spel.java`** - MAJOR VIOLATION ⚠️

**Current Responsibilities:**
- Game initialization and setup
- Command processing and parsing
- User input handling with Scanner
- Observer management setup
- Joker selection logic
- Game loop management

**Problems:**
- Mixes UI concerns with business logic
- Command processing mixed with game initialization
- Hard to change input method or add new commands

**Recommended Refactoring:**

```java
// 1. GameInitializer.java - Setup logic
public class GameInitializer {
    public Spel initializeGame(String spelNaam) { }
    public void setupObservers(Speler speler, ScrumKennisLogger logger, KamerVoortgangsMonitor monitor) { }
    public Speler createPlayer(String naam) { }
}

// 2. CommandProcessor.java - Command handling
public class CommandProcessor {
    public void processCommand(String command, Speler speler) throws SQLException { }
    private void handleMovement(String[] parts, Speler speler) { }
    private void handleJokerUsage(Speler speler) { }
    private void handleStatus(Speler speler) { }
}

// 3. UserInputHandler.java - Input management
public class UserInputHandler {
    private Scanner scanner;
    
    public String getPlayerName() { }
    public String getNextCommand() { }
    public String getJokerChoice() { }
}

// 4. JokerSelector.java - Joker selection
public class JokerSelector {
    public void selectJokerForPlayer(Speler speler, String choice) { }
    private Joker createJoker(String type) { }
}

// 5. Refactored Spel.java - Orchestration
public class Spel {
    private GameInitializer initializer;
    private CommandProcessor commandProcessor;
    private UserInputHandler inputHandler;
    private JokerSelector jokerSelector;
    
    // Orchestrates the game flow
}
```

### 3. **`SPEL/Kamer.java`** - MODERATE VIOLATION ⚠️

**Current Responsibilities:**
- Question handling logic
- Direct user interaction (Scanner usage)
- Hint management
- Monster combat logic
- Joker acceptance

**Problems:**
- UI logic mixed with business logic
- Hard to test without user input
- Combat logic embedded in room logic

**Recommended Refactoring:**

```java
// 1. QuestionHandler.java - Question logic
public class QuestionHandler {
    public boolean askQuestion(VraagStrategie vraag, Monster monster) { }
    private void handleCorrectAnswer(Monster monster) { }
    private void handleIncorrectAnswer(Monster monster) { }
}

// 2. UserInteractionService.java - Input/output
public class UserInteractionService {
    private Scanner scanner;
    
    public String getAnswer() { }
    public boolean askForHint() { }
    public void displayMessage(String message) { }
}

// 3. CombatManager.java - Monster battles
public class CombatManager {
    public void handleCombat(Monster monster, VraagStrategie vraag) { }
    public void defeatMonster(Monster monster, Speler speler) { }
}

// 4. Refactored Kamer.java - Room coordination
public abstract class Kamer implements JokerAcceptor {
    private QuestionHandler questionHandler;
    private UserInteractionService userService;
    private CombatManager combatManager;
    
    // Coordinates room activities
}
```

---

## 🔵 ISP (Interface Segregation Principle) Opportunities

### 1. **`SPEL/VraagStrategie.java`** - CAN BE SEGREGATED

**Current Interface:**
```java
public interface VraagStrategie {
    void toonVraag();                           // Display concern
    boolean controleerAntwoord(String antwoord); // Validation concern
    String positieveFeedback();                 // Feedback concern
    String negatieveFeedback();                 // Feedback concern
}
```

**Problem:** Clients that only need to validate answers are forced to implement display and feedback methods.

**Recommended Split:**

```java
// 1. Question display responsibility
public interface QuestionDisplayer {
    void toonVraag();
}

// 2. Answer validation responsibility
public interface AnswerValidator {
    boolean controleerAntwoord(String antwoord);
}

// 3. Feedback provision responsibility
public interface FeedbackProvider {
    String positieveFeedback();
    String negatieveFeedback();
}

// 4. Composite interface for backward compatibility
public interface VraagStrategie extends QuestionDisplayer, AnswerValidator, FeedbackProvider {
    // Combines all three interfaces
}
```

### 2. **New Segregated Interfaces**

```java
// Movement capability
public interface Moveable {
    void verplaats(int nieuwePositie);
    int getHuidigeKamer();
}

// Persistence capability
public interface Persistable {
    void saveToDatabase();
    void loadFromDatabase();
}

// Observer pattern capability
public interface Observable {
    void registerObserver(VoortgangsMonitor observer);
    void removeObserver(VoortgangsMonitor observer);
    void notifyObservers();
}

// Combat capability
public interface Combatable {
    void aanval();
    void ontvangSchade(int schade);
    int getLevenspunten();
}

// Knowledge management
public interface KnowledgeManager {
    void verhoogScrumKennis(int aantal);
    void verlaagScrumKennis(int aantal);
    int getScrumKennis();
}

// Room tracking capability
public interface RoomTrackable {
    boolean isKamerBezocht(int kamerNr);
    void markRoomVisited(int kamerNr);
}
```

---

## 📋 Implementation Priority Matrix

| File | Priority | Principle | Effort | Impact | Action Required |
|------|----------|-----------|--------|--------|-----------------|
| `SPEL/Speler.java` | 🔥 Critical | SRP | High | High | Split into 5 classes |
| `SPEL/Spel.java` | 🔥 High | SRP | High | High | Split into 4 classes |
| `SPEL/Kamer.java` | ⚡ Medium | SRP | Medium | Medium | Extract 3 services |
| `SPEL/VraagStrategie.java` | ⚡ Medium | ISP | Low | Medium | Split into 3 interfaces |
| Create new interfaces | ✅ Low | ISP | Low | Low | Add segregated interfaces |

---

## 🎯 Step-by-Step Implementation Guide

### Phase 1: Critical SRP Violations (Week 1-2)

#### Step 1.1: Refactor Speler.java
```bash
# Create new files:
touch SPEL/SpelerState.java
touch SPEL/SpelerPersistence.java  
touch SPEL/SpelerObservable.java
touch SPEL/JokerManager.java
touch SPEL/RoomTracker.java
```

**Implementation Order:**
1. Create `SpelerState.java` with basic data
2. Create `SpelerPersistence.java` and move database operations
3. Create `SpelerObservable.java` and move observer pattern
4. Create `JokerManager.java` and move joker logic
5. Create `RoomTracker.java` and move room tracking
6. Refactor `Speler.java` to use composition

#### Step 1.2: Refactor Spel.java
```bash
# Create new files:
touch SPEL/GameInitializer.java
touch SPEL/CommandProcessor.java
touch SPEL/UserInputHandler.java
touch SPEL/JokerSelector.java
```

### Phase 2: Interface Segregation (Week 3)

#### Step 2.1: Split VraagStrategie
```bash
# Create new interfaces:
touch SPEL/QuestionDisplayer.java
touch SPEL/AnswerValidator.java
touch SPEL/FeedbackProvider.java
```

#### Step 2.2: Create New Segregated Interfaces
```bash
# Create capability interfaces:
touch SPEL/Moveable.java
touch SPEL/Persistable.java
touch SPEL/Observable.java
touch SPEL/Combatable.java
touch SPEL/KnowledgeManager.java
touch SPEL/RoomTrackable.java
```

### Phase 3: Moderate Violations (Week 4)

#### Step 3.1: Refactor Kamer.java
```bash
# Create service classes:
touch SPEL/QuestionHandler.java
touch SPEL/UserInteractionService.java
touch SPEL/CombatManager.java
```

---

## 🧪 Testing Strategy

### Unit Testing Benefits After Refactoring

**Before Refactoring:**
- Hard to test `Speler` without database
- Cannot test command processing without UI
- Difficult to mock dependencies

**After Refactoring:**
```java
// Example: Testing SpelerState in isolation
@Test
public void testScrumKennisIncrease() {
    SpelerState state = new SpelerState("TestPlayer");
    state.verhoogScrumKennis(5);
    assertEquals(5, state.getScrumKennis());
}

// Example: Testing CommandProcessor with mocks
@Test
public void testMovementCommand() {
    CommandProcessor processor = new CommandProcessor();
    Speler mockSpeler = mock(Speler.class);
    
    processor.processCommand("ga naar kamer 1", mockSpeler);
    
    verify(mockSpeler).verplaats(1);
}
```

---

## 📊 Benefits Summary

### SRP Benefits:
- ✅ **Easier maintenance** - Each class has one reason to change
- ✅ **Better testability** - Can test individual responsibilities
- ✅ **Improved readability** - Smaller, focused classes
- ✅ **Reduced coupling** - Dependencies are more explicit

### ISP Benefits:
- ✅ **Flexible implementations** - Classes implement only needed interfaces
- ✅ **Better dependency injection** - Can inject specific capabilities
- ✅ **Reduced interface pollution** - No unused methods
- ✅ **Easier mocking** - Smaller interfaces are easier to mock

---

## 🚀 Migration Strategy

### Backward Compatibility
1. Keep original classes during transition
2. Mark old methods as `@Deprecated`
3. Gradually migrate callers to new structure
4. Remove deprecated code in final phase

### Risk Mitigation
1. **Start with least coupled classes** (SpelerState)
2. **Maintain comprehensive tests** during refactoring
3. **Refactor incrementally** - one responsibility at a time
4. **Use feature flags** for new implementations

---

## 📝 Code Examples

### Before and After: Speler Class

**Before (SRP Violation):**
```java
public class Speler {
    // State management
    private String naam;
    private int scrumKennis;
    
    // Persistence
    private SpelerRepository repository;
    
    // Observer pattern
    private List<VoortgangsMonitor> observers;
    
    // Joker management
    private Joker joker;
    
    // All responsibilities mixed together
    public void verhoogScrumKennis(int aantal) {
        this.scrumKennis += aantal;  // State
        repository.updateScrumKennis(this.naam, this.scrumKennis);  // Persistence
        notifyObservers();  // Observer pattern
    }
}
```

**After (SRP Compliant):**
```java
public class Speler {
    private SpelerState state;
    private SpelerPersistence persistence;
    private SpelerObservable observable;
    private JokerManager jokerManager;
    
    public void verhoogScrumKennis(int aantal) {
        state.verhoogScrumKennis(aantal);  // Delegate to state
        persistence.updateScrumKennis(state);  // Delegate to persistence
        observable.notifyObservers(state);  // Delegate to observer
    }
}
```

---

## 🎯 Success Metrics

### Code Quality Metrics
- **Cyclomatic Complexity**: Target < 10 per method
- **Class Size**: Target < 200 lines per class
- **Method Count**: Target < 20 methods per class
- **Interface Size**: Target < 5 methods per interface

### Maintainability Metrics
- **Test Coverage**: Target > 80%
- **Coupling**: Reduce afferent/efferent coupling
- **Cohesion**: Increase LCOM (Lack of Cohesion of Methods) score

---

## 📚 Additional Resources

### SOLID Principles References
- [Uncle Bob's SOLID Principles](https://blog.cleancoder.com/uncle-bob/2020/10/18/Solid-Relevance.html)
- [Interface Segregation Principle](https://stackify.com/interface-segregation-principle/)
- [Single Responsibility Principle](https://stackify.com/solid-design-principles/)

### Refactoring Techniques
- [Martin Fowler's Refactoring Catalog](https://refactoring.com/catalog/)
- [Extract Class Refactoring](https://refactoring.guru/extract-class)
- [Extract Interface Refactoring](https://refactoring.guru/extract-interface)

---

*Generated on: 2025-05-26*  
*Project: ScrumGameGroupD-Abdul*  
*Focus: ISP & SRP Implementation*
