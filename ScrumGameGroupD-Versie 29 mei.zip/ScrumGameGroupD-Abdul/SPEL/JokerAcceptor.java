public interface JokerAcceptor {
    void accepteer(Joker joker);
}
