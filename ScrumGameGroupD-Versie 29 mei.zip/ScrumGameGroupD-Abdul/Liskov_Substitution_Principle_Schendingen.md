# Liskov Substitution Principle Schendingen - Analyse en Oplossingen

## Inhoudsopgave
1. [Inleiding tot het Liskov Substitution Principle](#inleiding)
2. [Geïdentificeerde Schendingen](#schendingen)
3. [Oplossingen en Refactoring](#oplossingen)
4. [Implementatie Roadmap](#roadmap)
5. [Conclusie](#conclusie)

---

## 1. Inleiding tot het Liskov Substitution Principle {#inleiding}

Het **Liskov Substitution Principle (LSP)** is het derde principe van de SOLID principes en stelt dat:

> *"Objecten van een superklasse moeten vervangbaar zijn door objecten van hun subklassen zonder de correctheid van het programma te breken."*

### Kernregels van LSP:
- **Pre-condities** mogen niet sterker worden in subklassen
- **Post-condities** mogen niet zwakker worden in subklassen  
- **Invarianten** van de superklasse moeten behouden blijven
- **Gedrag** moet consistent zijn tussen super- en subklassen

### Waarom LSP belangrijk is:
- Zorgt voor **voorspelbaar gedrag** in polymorfisme
- Maakt **veilige substitutie** mogelijk
- Verbetert **code maintainability**
- Voorkomt **runtime fouten** door onverwacht gedrag

---

## 2. Geïdentificeerde Schendingen {#schendingen}

### Schending 1: Monster Hiërarchie - Inconsistent `versla()` Gedrag

#### **Probleem Beschrijving**
De `Monster` hiërarchie toont inconsistent gedrag in de `versla()` methode. De `Zombie` klasse overschrijft deze methode met ander gedrag dan de parent klasse.

#### **Huidige Code**
```java
// Monster.java (Parent)
public void versla(Speler speler) {
    System.out.println("Je hebt de " + getNaam() + " verslagen!");
    speler.verhoogScrumKennis(levenspunten);
}

// Zombie.java (Subklasse)
@Override
public void versla(Speler speler) {
    System.out.println("De zombie is neergehaald.");  // ← Andere output!
    speler.verhoogScrumKennis(levenspunten);
}

// Draak.java en Reuzenspin.java
// Geen override - gebruiken parent implementatie
```

#### **LSP Schending**
- **Inconsistent gedrag**: `Zombie` toont andere output dan verwacht
- **Onvoorspelbaarheid**: Client code kan niet vertrouwen op consistent gedrag
- **Broken substitution**: `Monster monster = new Zombie()` gedraagt zich anders dan `Monster monster = new Draak()`

#### **Impact**
```java
// Deze code gedraagt zich inconsistent:
List<Monster> monsters = Arrays.asList(new Zombie(), new Draak(), new Reuzenspin());
for (Monster monster : monsters) {
    monster.versla(speler); // Verschillende output formaten!
}
```

---

### Schending 2: VraagStrategie Hiërarchie - Gemengde Implementatie Patronen

#### **Probleem Beschrijving**
De `VraagStrategie` hiërarchie heeft een inconsistente structuur waarbij sommige klassen direct het interface implementeren en anderen een abstract klasse gebruiken.

#### **Huidige Code**
```java
// VraagStrategie.java (Interface)
public interface VraagStrategie {
    void toonVraag();
    boolean controleerAntwoord(String antwoord);
    String positieveFeedback();
    String negatieveFeedback();
}

// AbstractVraagStrategie.java (Bestaat maar wordt niet gebruikt)
public abstract class AbstractVraagStrategie implements VraagStrategie {
    protected String vraag;
    protected String positieveFeedback;
    protected String negatieveFeedback;
    // ... implementatie van gemeenschappelijke methoden
}

// OpenvraagStrategie.java (Implementeert direct interface)
public class OpenvraagStrategie implements VraagStrategie {
    private String vraag;                    // ← Code duplicatie
    private String positieveFeedback;        // ← Code duplicatie  
    private String negatieveFeedback;        // ← Code duplicatie
    // ... volledige implementatie
}

// MeerkeuzeStrategie.java (Implementeert ook direct interface)
public class MeerkeuzeStrategie implements VraagStrategie {
    private String positieveFeedback;        // ← Code duplicatie
    private String negatieveFeedback;        // ← Code duplicatie
    private String vraag;                    // ← Code duplicatie
    // ... volledige implementatie
}
```

#### **LSP Schending**
- **Inconsistente hiërarchie**: Gemengde implementatie patronen
- **Code duplicatie**: Feedback logica wordt herhaald
- **Maintenance problemen**: Wijzigingen moeten op meerdere plaatsen gebeuren

---

### Schending 3: Joker Hiërarchie - Verschillende Gebruiksbeperkingen

#### **Probleem Beschrijving**
De `Joker` subklassen hebben verschillende pre-condities voor gebruik, wat het LSP schendt.

#### **Huidige Code**
```java
// Joker.java (Parent)
public abstract boolean kanGebruiktWordenIn(Kamer kamer);

// HintJoker.java
@Override
public boolean kanGebruiktWordenIn(Kamer kamer) {
    return true;  // ← Kan overal gebruikt worden
}

// SleutelJoker.java  
@Override
public boolean kanGebruiktWordenIn(Kamer kamer) {
    return kamer instanceof KamerDaily || kamer instanceof KamerReview;  // ← Beperkte gebruik
}
```

#### **LSP Schending**
- **Verschillende pre-condities**: `SleutelJoker` heeft sterkere pre-condities
- **Onverwacht gedrag**: Client code kan niet vertrouwen op consistent gebruik
- **Broken substitution**: `Joker joker = new SleutelJoker()` werkt niet overal waar `Joker joker = new HintJoker()` wel werkt

#### **Impact**
```java
// Deze code kan falen:
public void gebruikJoker(Joker joker, Kamer kamer) {
    if (joker.kanGebruiktWordenIn(kamer)) {  // Kan false zijn voor SleutelJoker
        joker.gebruikIn(kamer);
    }
}
```

---

### Schending 4: Kamer Hiërarchie - Inconsistente `geefExtraSleutel()` Implementatie

#### **Probleem Beschrijving**
De `Kamer` parent klasse heeft een `geefExtraSleutel()` methode die niet voor alle subklassen logisch is.

#### **Huidige Code**
```java
// Kamer.java (Parent)
void geefExtraSleutel(Speler speler) {
    System.out.println("Je hebt een extra sleutel gevonden in de " + getKamerNaam() + "!");
    speler.setAantalSleutels(speler.getAantalSleutels() + 1);
}

// SleutelJoker.java gebruikt deze methode
@Override
protected void doeGebruikIn(Kamer kamer) {
    System.out.println("🔑 Sleutel Joker geactiveerd!");
    Speler speler = Spel.getHuidigeSpeler();
    kamer.geefExtraSleutel(speler);  // ← Roept parent methode aan
}
```

#### **LSP Schending**
- **Semantische inconsistentie**: Niet alle kamers zouden logisch sleutels moeten geven
- **Forced inheritance**: Subklassen erven gedrag dat niet altijd passend is
- **Violation of ISP**: Interface is te breed voor sommige implementaties

---

### Schending 5: VraagStrategie - Gemiste Abstractie Voordelen

#### **Probleem Beschrijving**
Door `AbstractVraagStrategie` te negeren, missen concrete implementaties de voordelen van gemeenschappelijke functionaliteit.

#### **Huidige Code**
```java
// OpenvraagStrategie.java
@Override
public String positieveFeedback() {
    return positieveFeedback;  // ← Simpele getter
}

@Override
public String negatieveFeedback() {
    return negatieveFeedback;  // ← Simpele getter
}

// MeerkeuzeStrategie.java  
@Override
public String positieveFeedback() {
    return positieveFeedback;  // ← Identieke implementatie
}

@Override
public String negatieveFeedback() {
    return negatieveFeedback;  // ← Identieke implementatie
}
```

#### **LSP Schending**
- **Code duplicatie**: Identieke implementaties in meerdere klassen
- **Inconsistente hiërarchie**: Abstract klasse wordt genegeerd
- **Maintenance overhead**: Wijzigingen moeten op meerdere plaatsen

---

## 3. Oplossingen en Refactoring {#oplossingen}

### Oplossing 1: Monster Hiërarchie Consistentie

#### **Refactored Code**
```java
// Monster.java (Verbeterde parent)
public abstract class Monster {
    protected int levenspunten;
    
    public abstract void aanval();
    public abstract String getNaam();
    public abstract String beschrijving();
    
    public int getLevenspunten() {
        return levenspunten;
    }
    
    // Template method voor consistente output
    public final void versla(Speler speler) {
        System.out.println(getVerslagenBericht());
        speler.verhoogScrumKennis(levenspunten);
        voerExtraActiesUit(speler);
    }
    
    // Hook method voor subklasse-specifiek gedrag
    protected String getVerslagenBericht() {
        return "Je hebt de " + getNaam() + " verslagen!";
    }
    
    // Hook method voor extra acties
    protected void voerExtraActiesUit(Speler speler) {
        // Default: geen extra acties
    }
    
    public void ontvangSchade(int schade) {
        levenspunten -= schade;
        System.out.println("De " + getNaam() + " ontvangt " + schade + " schade. Levenspunten: " + levenspunten);
        if (levenspunten <= 0) {
            System.out.println("De " + getNaam() + " is verslagen!");
        } else {
            System.out.println("De " + getNaam() + " is nog steeds in leven met " + levenspunten + " levenspunten.");
        }
    }
}

// Zombie.java (Aangepaste subklasse)
public class Zombie extends Monster {
    public Zombie() {
        this.levenspunten = 50;
    }

    @Override
    public void aanval() {
        System.out.println("🧟‍🧟🧟🧟🧟‍🧟‍  ️De zombie bijt langzaam maar hard! 🧟‍🧟🧟🧟🧟‍🧟‍");
    }

    @Override
    public String getNaam() {
        return "Zombie";
    }

    @Override
    public String beschrijving() {
        return "Een trage, rottende zombie die toch gevaarlijk dichtbij kan komen.";
    }
    
    // Optioneel: aangepast bericht behouden
    @Override
    protected String getVerslagenBericht() {
        return "De zombie is neergehaald.";
    }
}
```

#### **Voordelen**
- ✅ **Consistente interface**: Alle monsters gedragen zich voorspelbaar
- ✅ **Flexibiliteit**: Subklassen kunnen nog steeds aangepast gedrag hebben
- ✅ **Template Method Pattern**: Structuur is gedefinieerd, details kunnen variëren

---

### Oplossing 2: VraagStrategie Hiërarchie Herstructurering

#### **Refactored Code**
```java
// AbstractVraagStrategie.java (Verbeterde abstract klasse)
public abstract class AbstractVraagStrategie implements VraagStrategie {
    protected final String vraag;
    protected final String positieveFeedback;
    protected final String negatieveFeedback;
    
    public AbstractVraagStrategie(String vraag, String positieveFeedback, String negatieveFeedback) {
        this.vraag = Objects.requireNonNull(vraag, "Vraag mag niet null zijn");
        this.positieveFeedback = Objects.requireNonNull(positieveFeedback, "Positieve feedback mag niet null zijn");
        this.negatieveFeedback = Objects.requireNonNull(negatieveFeedback, "Negatieve feedback mag niet null zijn");
    }
    
    @Override
    public final void toonVraag() {
        System.out.println(vraag);
        toonExtraVraagInfo();
    }
    
    // Hook method voor subklasse-specifieke vraag info
    protected void toonExtraVraagInfo() {
        // Default: geen extra info
    }
    
    @Override
    public final String positieveFeedback() {
        return positieveFeedback;
    }
    
    @Override
    public final String negatieveFeedback() {
        return negatieveFeedback;
    }
    
    @Override
    public abstract boolean controleerAntwoord(String antwoord);
}

// OpenvraagStrategie.java (Refactored)
public class OpenvraagStrategie extends AbstractVraagStrategie {
    private final String verwachtAntwoord;
    private final String[] sleutelwoorden;
    
    public OpenvraagStrategie(String vraag, String verwachtAntwoord, String[] sleutelwoorden,
                             String positieveFeedback, String negatieveFeedback) {
        super(vraag, positieveFeedback, negatieveFeedback);
        this.verwachtAntwoord = Objects.requireNonNull(verwachtAntwoord);
        this.sleutelwoorden = Objects.requireNonNull(sleutelwoorden);
    }
    
    @Override
    public boolean controleerAntwoord(String gegevenAntwoord) {
        if (gegevenAntwoord == null) return false;
        
        if (gegevenAntwoord.equalsIgnoreCase(verwachtAntwoord)) {
            return true;
        }

        return Arrays.stream(sleutelwoorden)
                .anyMatch(sleutelwoord -> 
                    gegevenAntwoord.toLowerCase().contains(sleutelwoord.toLowerCase()));
    }
}

// MeerkeuzeStrategie.java (Refactored)
public class MeerkeuzeStrategie extends AbstractVraagStrategie {
    private final String[] opties;
    private final int correcteOptieIndex;
    
    public MeerkeuzeStrategie(String vraag, String[] opties, int correcteOptieIndex,
                              String positieveFeedback, String negatieveFeedback) {
        super(vraag, positieveFeedback, negatieveFeedback);
        this.opties = Objects.requireNonNull(opties);
        this.correcteOptieIndex = correcteOptieIndex;
        
        if (correcteOptieIndex < 0 || correcteOptieIndex >= opties.length) {
            throw new IllegalArgumentException("Correcte optie index is buiten bereik");
        }
    }
    
    @Override
    protected void toonExtraVraagInfo() {
        for (int i = 0; i < opties.length; i++) {
            System.out.println((i + 1) + ". " + opties[i]);
        }
    }

    @Override
    public boolean controleerAntwoord(String antwoord) {
        if (antwoord == null) return false;
        
        try {
            int keuze = Integer.parseInt(antwoord.trim());
            return keuze == (correcteOptieIndex + 1); // +1 omdat gebruiker 1-based indexing ziet
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
```

#### **Voordelen**
- ✅ **Geen code duplicatie**: Gemeenschappelijke functionaliteit in abstract klasse
- ✅ **Consistente hiërarchie**: Alle implementaties gebruiken dezelfde basis
- ✅ **Template Method Pattern**: Structuur gedefinieerd, details per subklasse
- ✅ **Betere maintainability**: Wijzigingen op één plek

---

### Oplossing 3: Joker Hiërarchie Herstructurering

#### **Probleem Analyse**
Het hoofdprobleem is dat `SleutelJoker` sterkere pre-condities heeft dan `HintJoker`. Dit schendt LSP omdat clients niet kunnen vertrouwen op consistent gedrag.

#### **Oplossing A: Joker Categorisatie**
```java
// JokerType.java (Nieuwe enum)
public enum JokerType {
    UNIVERSEEL,  // Kan overal gebruikt worden
    BEPERKT      // Heeft specifieke restricties
}

// Joker.java (Verbeterde parent)
public abstract class Joker {
    protected boolean isUsed = false;
    
    public abstract JokerType getType();
    public abstract boolean kanGebruiktWordenIn(Kamer kamer);
    
    public final void gebruikIn(Kamer kamer) {
        if (isUsed) {
            System.out.println("Deze joker is al gebruikt.");
            return;
        }
        
        if (!kanGebruiktWordenIn(kamer)) {
            System.out.println("Deze joker kan niet in deze kamer worden gebruikt.");
            return;
        }
        
        doeGebruikIn(kamer);
        isUsed = true;
    }

    protected abstract void doeGebruikIn(Kamer kamer);
    
    public boolean isUsed() {
        return isUsed;
    }
    
    public void setUsed(boolean used) {
        this.isUsed = used;
    }
    
    public abstract String beschrijving();
}

// UniverseleJoker.java (Nieuwe abstract klasse)
public abstract class UniverseleJoker extends Joker {
    @Override
    public final JokerType getType() {
        return JokerType.UNIVERSEEL;
    }
    
    @Override
    public final boolean kanGebruiktWordenIn(Kamer kamer) {
        return true; // Universele jokers werken overal
    }
}

// BeperktJoker.java (Nieuwe abstract klasse)
public abstract class BeperktJoker extends Joker {
    @Override
    public final JokerType getType() {
        return JokerType.BEPERKT;
    }
    
    // Subklassen moeten specifieke restricties implementeren
    @Override
    public abstract boolean kanGebruiktWordenIn(Kamer kamer);
}

// HintJoker.java (Refactored)
public class HintJoker extends UniverseleJoker {
    @Override
    protected void doeGebruikIn(Kamer kamer) {
        System.out.println("🎭 Hint Joker geactiveerd!");
        kamer.geefHint();
    }

    @Override
    public String beschrijving() {
        return "Dit is een hint joker. Je kan deze joker gebruiken om hints te krijgen voor de vragen in de kamers.";
    }
}

// SleutelJoker.java (Refactored)
public class SleutelJoker extends BeperktJoker {
    @Override
    public boolean kanGebruiktWordenIn(Kamer kamer) {
        return kamer instanceof KamerDaily || kamer instanceof KamerReview;
    }

    @Override
    protected void doeGebruikIn(Kamer kamer) {
        System.out.println("🔑 Sleutel Joker geactiveerd!");
        Speler speler = Spel.getHuidigeSpeler();
        
        if (kamer instanceof SleutelProvider) {
            ((SleutelProvider) kamer).geefExtraSleutel(speler);
        } else {
            // Fallback voor backward compatibility
            System.out.println("Je hebt een extra sleutel gevonden!");
            speler.setAantalSleutels(speler.getAantalSleutels() + 1);
        }
        
        System.out.println("Je hebt nu " + speler.getAantalSleutels() + " sleutels.");
    }

    @Override
    public String beschrijving() {
        return "Dit is een Sleutel Joker. Je kan deze joker gebruiken om een extra sleutel te krijgen in de Daily Scrum of Review kamer.";
    }
}
```

#### **Client Code Verbetering**
```java
// JokerManager.java (Nieuwe utility klasse)
public class JokerManager {
    public static boolean kanJokerGebruiktWorden(Joker joker, Kamer kamer) {
        return joker.kanGebruiktWordenIn(kamer);
    }
    
    public static List<Joker> filterBeschikbareJokers(List<Joker> jokers, Kamer kamer) {
        return jokers.stream()
                .filter(joker -> !joker.isUsed())
                .filter(joker -> joker.kanGebruiktWordenIn(kamer))
                .collect(Collectors.toList());
    }
    
    public static void toonBeschikbareJokers(List<Joker> jokers, Kamer kamer) {
        List<Joker> beschikbaar = filterBeschikbareJokers(jokers, kamer);
        
        if (beschikbaar.isEmpty()) {
            System.out.println("Geen jokers beschikbaar in deze kamer.");
            return;
        }
        
        System.out.println("Beschikbare jokers:");
        for (int i = 0; i < beschikbaar.size(); i++) {
            Joker joker = beschikbaar.get(i);
            System.out.println((i + 1) + ". " + joker.beschrijving() + 
                             " (Type: " + joker.getType() + ")");
        }
    }
}
```

#### **Voordelen**
- ✅ **Expliciete categorisatie**: Duidelijk onderscheid tussen joker types
- ✅ **LSP compliance**: Subklassen gedragen zich consistent binnen hun categorie
- ✅ **Betere client code**: Duidelijke verwachtingen over joker gedrag

---

### Oplossing 4: Kamer Hiërarchie Interface Segregation

#### **Probleem Analyse**
De `geefExtraSleutel()` methode in de `Kamer` parent klasse is niet voor alle subklassen relevant, wat het Interface Segregation Principle schendt.

#### **Refactored Code**
```java
// SleutelProvider.java (Nieuwe interface)
public interface SleutelProvider {
    void geefExtraSleutel(Speler speler);
    boolean kanSleutelGeven();
}

// Kamer.java (Refactored parent)
public abstract class Kamer implements JokerAcceptor {
    protected String beschrijving;
    protected VraagStrategie vraag;
    protected Monster monster;

    public Kamer(String beschrijving) {
        this.beschrijving = beschrijving;
    }

    abstract void geefHint();
    
    // Verwijderd: geefExtraSleutel() - nu in interface

    public abstract void betreed();
    
    protected abstract String getKamerNaam();
    
    // ... rest van de implementatie blijft hetzelfde
}

// KamerDaily.java (Implementeert SleutelProvider)
public class KamerDaily extends Kamer implements SleutelProvider {
    private String dailyDetails;

    public KamerDaily(String beschrijving, String dailyDetails) {
        super(beschrijving);
        this.dailyDetails = dailyDetails;
        this.vraag = maakDailyVraag();
        this.monster = new Zombie();
    }
    
    @Override
    public void geefExtraSleutel(Speler speler) {
        System.out.println("Je hebt een extra sleutel gevonden tijdens de Daily Scrum!");
        speler.setAantalSleutels(speler.getAantalSleutels() + 1);
    }
    
    @Override
    public boolean kanSleutelGeven() {
        return true; // Daily kamers kunnen altijd sleutels geven
    }
    
    // ... rest van implementatie
}

// KamerReview.java (Implementeert SleutelProvider)
public class KamerReview extends Kamer implements SleutelProvider {
    private int reviewScore;

    public KamerReview(String beschrijving, int reviewScore) {
        super(beschrijving);
        this.reviewScore = reviewScore;
        this.vraag = maakReviewVraag();
        this.monster = new Zombie();
    }
    
    @Override
    public void geefExtraSleutel(Speler speler) {
        if (reviewScore >= 8) {
            System.out.println("Uitstekende review! Je krijgt een bonus sleutel!");
            speler.setAantalSleutels(speler.getAantalSleutels() + 2);
        } else {
            System.out.println("Je hebt een sleutel gevonden na de review.");
            speler.setAantalSleutels(speler.getAantalSleutels() + 1);
        }
    }
    
    @Override
    public boolean kanSleutelGeven() {
        return true;
    }
    
    // ... rest van implementatie
}

// KamerPlanning.java (Implementeert GEEN SleutelProvider)
public class KamerPlanning extends Kamer {
    // Deze kamer geeft geen sleutels - implementeert SleutelProvider niet
    
    // ... implementatie zonder sleutel functionaliteit
}
```

#### **Verbeterde SleutelJoker**
```java
// SleutelJoker.java (Aangepast voor nieuwe structuur)
public class SleutelJoker extends BeperktJoker {
    @Override
    public boolean kanGebruiktWordenIn(Kamer kamer) {
        return kamer instanceof SleutelProvider && 
               ((SleutelProvider) kamer).kanSleutelGeven();
    }

    @Override
    protected void doeGebruikIn(Kamer kamer) {
        System.out.println("🔑 Sleutel Joker geactiveerd!");
        Speler speler = Spel.getHuidigeSpeler();
        
        if (kamer instanceof SleutelProvider) {
            ((SleutelProvider) kamer).geefExtraSleutel(speler);
            System.out.println("Je hebt nu " + speler.getAantalSleutels() + " sleutels.");
        }
    }

    @Override
    public String beschrijving() {
        return "Dit is een Sleutel Joker. Je kan deze joker gebruiken om een extra sleutel te krijgen in kamers die sleutels kunnen geven.";
    }
}
```

#### **Voordelen**
- ✅ **Interface Segregation**: Alleen relevante kamers implementeren SleutelProvider
- ✅ **LSP Compliance**: Geen geforceerde inheritance van irrelevante functionaliteit
- ✅ **Flexibiliteit**: Verschillende kamers kunnen verschillende sleutel logica hebben
- ✅ **Type Safety**: Compile-time controle op sleutel functionaliteit

---

## 4. Implementatie Roadmap {#roadmap}

### Fase 1: Kritieke LSP Schendingen (Week 1-2)
**Prioriteit: Hoog**

#### Stap 1.1: Monster Hiërarchie Refactoring
- [ ] Implementeer Template Method pattern in `Monster.java`
- [ ] Refactor `Zombie.java` om hook methods te gebruiken
- [ ] Test alle monster interacties
- [ ] Update unit tests

#### Stap 1.2: VraagStrategie Hiërarchie Cleanup
- [ ] Verbeter `AbstractVraagStrategie.java`
- [ ] Refactor `OpenvraagStrategie.java` om abstract klasse te gebruiken
- [ ] Refactor `MeerkeuzeStrategie.java` om abstract klasse te gebruiken
- [ ] Verwijder code duplicatie
- [ ] Update alle kamer implementaties

**Geschatte tijd**: 8-12 uur
**Impact**: Hoog - Lost fundamentele inconsistenties op

### Fase 2: Joker Systeem Herstructurering (Week 2-3)
**Prioriteit: Medium-Hoog**

#### Stap 2.1: Joker Categorisatie
- [ ] Creëer `JokerType` enum
- [ ] Implementeer `UniverseleJoker` en `BeperktJoker` abstract klassen
- [ ] Refactor bestaande joker implementaties
- [ ] Implementeer `JokerManager` utility klasse

#### Stap 2.2: Client Code Updates
- [ ] Update alle joker gebruik in game logic
- [ ] Implementeer betere error handling
- [ ] Add joker type indicators in UI

**Geschatte tijd**: 6-10 uur
**Impact**: Medium - Verbetert joker systeem consistentie

### Fase 3: Interface Segregation (Week 3-4)
**Prioriteit: Medium**

#### Stap 3.1: SleutelProvider Interface
- [ ] Creëer `SleutelProvider` interface
- [ ] Refactor relevante kamer klassen
- [ ] Update `SleutelJoker` implementatie
- [ ] Remove `geefExtraSleutel()` van `Kamer` parent

#### Stap 3.2: Testing en Validatie
- [ ] Comprehensive testing van alle wijzigingen
- [ ] Performance impact analyse
- [ ] Code review en documentatie update

**Geschatte tijd**: 4-6 uur
**Impact**: Medium - Verbetert interface design

### Fase 4: Validatie en Optimalisatie (Week 4)
**Prioriteit: Low-Medium**

#### Stap 4.1: Integration Testing
- [ ] End-to-end testing van alle scenarios
- [ ] Performance benchmarking
- [ ] Memory usage analyse

#### Stap 4.2: Documentatie en Training
- [ ] Update technische documentatie
- [ ] Code comments en JavaDoc
- [ ] Team training over nieuwe patterns

**Geschatte tijd**: 4-8 uur
**Impact**: Low - Consolidatie en knowledge transfer

### Totale Geschatte Tijd: 22-36 uur
### Aanbevolen Spreiding: 4 weken

---

## 5. Voor/Na Vergelijkingen

### Monster Hiërarchie

#### **Voor (LSP Schending)**
```java
// Inconsistent gedrag
Monster zombie = new Zombie();
Monster draak = new Draak();

zombie.versla(speler); // Output: "De zombie is neergehaald."
draak.versla(speler);  // Output: "Je hebt de Draak verslagen!"
```

#### **Na (LSP Compliant)**
```java
// Consistent gedrag met flexibiliteit
Monster zombie = new Zombie();
Monster draak = new Draak();

zombie.versla(speler); // Output: "De zombie is neergehaald." (via hook method)
draak.versla(speler);  // Output: "Je hebt de Draak verslagen!" (via default)

// Beide volgen dezelfde structuur: bericht + kennis verhogen + extra acties
```

### Joker Systeem

#### **Voor (LSP Schending)**
```java
// Onvoorspelbaar gedrag
Joker hint = new HintJoker();
Joker sleutel = new SleutelJoker();

hint.kanGebruiktWordenIn(kamerPlanning);    // true
sleutel.kanGebruiktWordenIn(kamerPlanning); // false - Onverwacht!
```

#### **Na (LSP Compliant)**
```java
// Voorspelbaar gedrag per categorie
UniverseleJoker hint = new HintJoker();
BeperktJoker sleutel = new SleutelJoker();

hint.kanGebruiktWordenIn(kamerPlanning);    // true - Verwacht voor universele joker
sleutel.kanGebruiktWordenIn(kamerPlanning); // false - Verwacht voor beperkte joker

// Client code kan nu correct omgaan met verschillende joker types
if (joker.getType() == JokerType.UNIVERSEEL) {
    // Kan overal gebruikt worden
} else {
    // Controleer eerst of het kan
}
```

---

## 6. Conclusie {#conclusie}

### Geïdentificeerde Problemen
Deze analyse heeft **5 significante LSP schendingen** geïdentificeerd in de codebase:

1. **Monster hiërarchie inconsistentie** - Verschillende output formaten
2. **VraagStrategie implementatie chaos** - Gemengde patronen en code duplicatie  
3. **Joker pre-conditie verschillen** - Onvoorspelbaar gebruik gedrag
4. **Kamer interface vervuiling** - Geforceerde inheritance van irrelevante functionaliteit
5. **Gemiste abstractie voordelen** - Onnodige code duplicatie

### Impact van Oplossingen

#### **Technische Voordelen**
- ✅ **Voorspelbaar gedrag** - Polymorfisme werkt zoals verwacht
- ✅ **Betere maintainability** - Wijzigingen op logische plaatsen
- ✅ **Reduced coupling** - Interfaces zijn meer focused
- ✅ **Code reuse** - Gemeenschappelijke functionaliteit in abstract klassen
- ✅ **Type safety** - Compile-time controles voorkomen runtime fouten

#### **Ontwikkelings Voordelen**
- ✅ **Makkelijker debugging** - Consistent gedrag maakt fouten voorspelbaar
- ✅ **Snellere feature development** - Duidelijke patterns om te volgen
- ✅ **Betere testability** - Consistent gedrag is makkelijker te testen
- ✅ **Team productivity** - Minder verwarring over class gedrag

#### **Lange Termijn Voordelen**
- ✅ **Scalability** - Nieuwe subklassen volgen duidelijke patterns
- ✅ **Refactoring safety** - LSP compliance maakt refactoring veiliger
- ✅ **Code quality** - Betere adherence aan SOLID principles
- ✅ **Knowledge transfer** - Nieuwe team members begrijpen code sneller

### Aanbevelingen

#### **Onmiddellijke Acties**
1. **Start met Monster hiërarchie** - Hoogste impact, relatief eenvoudig
2. **Implementeer VraagStrategie cleanup** - Lost veel code duplicatie op
3. **Plan Joker refactoring** - Complexer maar belangrijke verbetering

#### **Lange Termijn Strategie**
1. **Implementeer LSP checks** in code review process
2. **Add automated tests** voor polymorfisme scenarios  
3. **Regular architecture reviews** om nieuwe schendingen te voorkomen
4. **Team training** over SOLID principles

#### **Success Metrics**
- **Code duplicatie reductie**: Target 60-80% minder duplicated code
- **Bug reduction**: Minder polymorfisme-gerelateerde bugs
- **Development speed**: Snellere feature development door duidelijke patterns
- **Code review efficiency**: Minder tijd besteed aan architecture discussions

### Volgende Stappen

1. **Review dit document** met het development team
2. **Prioriteer implementatie** gebaseerd op team capacity
3. **Start met Fase 1** - Monster en VraagStrategie refactoring
4. **Monitor progress** en pas planning aan indien nodig
5. **Document lessons learned** voor toekomstige projecten

Door deze LSP schendingen aan te pakken, zal de codebase significant verbeteren in termen van maintainability, predictability, en overall code quality. De investering in refactoring zal zich terugbetalen door snellere development cycles en minder bugs in de toekomst.
