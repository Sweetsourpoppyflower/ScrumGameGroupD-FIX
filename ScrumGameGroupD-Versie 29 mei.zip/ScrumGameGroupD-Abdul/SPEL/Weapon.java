public abstract class Weapon {

    void attack() {
        System.out.println("Je valt het object aan.");
    }
}
